LOGIN APP - FIXED SPRING BOOT VERSION

The webpage files are in src/main/resources/static, so Spring Boot serves
index.html automatically at http://localhost:8080/.

1. In application.properties, set your actual MySQL password.
2. Ensure MySQL Server is running.
3. Import this folder in Eclipse:
   File -> Import -> Maven -> Existing Maven Projects
4. Run LoginAppApplication.java as Spring Boot App.
5. Open http://localhost:8080/ in your browser.
6. Register a user, then check MySQL Workbench:
   USE loginapp;
   SELECT * FROM users;

Note: This is a learning demo. Passwords are not yet securely hashed.
